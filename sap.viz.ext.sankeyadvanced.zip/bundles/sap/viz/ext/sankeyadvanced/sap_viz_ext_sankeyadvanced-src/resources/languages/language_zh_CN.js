sap.viz.extapi.env.Language
	.register({
		id: 'zh_CN',
		value: {
			IDS_VERSION_PUBLIC: '公版'
		}
	});