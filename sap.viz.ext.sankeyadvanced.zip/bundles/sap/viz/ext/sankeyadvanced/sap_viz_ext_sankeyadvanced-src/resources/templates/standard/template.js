var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.sankeyadvanced": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);